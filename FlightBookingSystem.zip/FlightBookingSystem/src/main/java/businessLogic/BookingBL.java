package businessLogic;

public class BookingBL {

}
