package businessLogic;

public class PlaneBL {

}
