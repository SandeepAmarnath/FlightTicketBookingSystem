package businessLogic;

public class SeatBL {

}
