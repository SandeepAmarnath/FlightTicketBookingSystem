package businessLogic;

public class TicketBL {

}
