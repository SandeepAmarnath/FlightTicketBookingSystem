package businessLogic;

public class TripBL {

}
