package model;

public interface IStorable {

}
