package model;

public enum SeatNumber {
	
	A1,A2,A3,          D1,D2,D3,          G1,G2,G3,
	B1,B2,B3,          E1,E2,E3,          H1,H2,H3,
	C1,C2,C3,          F1,F2,F3,          I1,I2,I3

}
