package model;

public enum SeatType {

	BusinessClass, EconomyClass
}
